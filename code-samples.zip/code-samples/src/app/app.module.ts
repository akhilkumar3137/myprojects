import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { RouterModule ,Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { ListEmployeComponent } from './employees/list-employe.component';
import { CreateEmployeeComponent } from './employees/create-employee.component';
import { FooterComponent } from './employees/footer.component';
import { ChangepasswordComponent } from './pages/changepassword.component';
import { CareersComponent } from './pages/careers.component';
import { CreateuserComponent } from './employees/createuser.component';


const appRoutes: Routes = [
  {path: 'changepassword', component: ChangepasswordComponent },
  {path: 'careers', component: CareersComponent },
  {path: 'home', component: ListEmployeComponent },
  {path: 'createuser', component: CreateuserComponent },
  {path: '', redirectTo: 'home', pathMatch:'full' }
]

@NgModule({
  declarations: [
    AppComponent,
    ListEmployeComponent,
    CreateEmployeeComponent,
    FooterComponent,
    ChangepasswordComponent,
    CareersComponent,
    CreateuserComponent
  ],
  imports: [
    BrowserModule,
	FormsModule,
	RouterModule.forRoot(appRoutes)
	
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
