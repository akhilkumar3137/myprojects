import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-createuser',
  templateUrl: './createuser.component.html'
})
export class CreateuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
	
  saveUser(empForm: NgForm): void {
	  console.log(empForm.value);
  }


}
