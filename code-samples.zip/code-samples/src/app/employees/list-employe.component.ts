import { Component, OnInit } from '@angular/core';
import { Employe } from '../models/employe.model';

@Component({
  selector: 'app-list-employe',
  templateUrl: './list-employe.component.html',
  styleUrls: ['../app.component.css']
})
export class ListEmployeComponent implements OnInit {
  employe: Employe[]=[
    {
		id:1,
		name:'akhil',
		gender:'male',
		photoPath:'assets/images/photo.jpg'
    },
    {
		id:1,
		name:'akhil kumar',
		gender:'Male',
		photoPath:'assets/images/photo.jpg'
    }
  ];
  constructor() { }

  ngOnInit() {
  }

}
