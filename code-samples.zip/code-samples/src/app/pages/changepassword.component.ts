import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
})
export class ChangepasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
