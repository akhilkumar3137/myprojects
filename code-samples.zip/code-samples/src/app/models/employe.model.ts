export class Employe{
	id:number;
	name:string;
	gender:string;
	photoPath!:string;
}
